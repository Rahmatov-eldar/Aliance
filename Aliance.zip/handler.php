<?php
$user_name = $_POST["username"];
$user_phone = $_POST["userphone"];
echo "Привет, " . $user_name . "</br>";
echo "Ваш телефон: <b>" . $user_phone . "</b>";